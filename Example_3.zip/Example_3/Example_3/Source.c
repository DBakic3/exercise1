#include<stdio.h>
int main()
{
	int a, b, c;
	a = 8;
	b = 9;
	c = a * b;
	printf("umnozak a i b je %d \n a zbroj je %d", c,a+b);
}