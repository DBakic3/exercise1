#include<stdio.h>
int main()
{
	int a, b, c;
	a = 5;
	b = 4;
	c = a + b;
	printf("zbroj 5 i 4 je %d", c);

}
